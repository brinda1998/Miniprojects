<!DOCTYPE html>
<html>
<head>
	<title>Admin</title>
	<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
	<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<script>
	function openpage()
	{
		location.replace("Agdb.php");
	}
</script>
<script>
	function openUsers()
	{
		location.replace("Userdb.php");
	}
</script>
<script>
	function openSer()
	{
		location.replace("Servreq.php");
	}
</script>
<style>
body {font-family: Arial, Helvetica, sans-serif;}

.navbar {
  width: 100%;
  background-color: #555;
  overflow: auto;
}

.navbar a {
  float: left;
  padding: 12px;
  color: white;
  text-decoration: none;
  font-size: 17px;
}

.navbar a:hover {
  background-color: #000;
}

.active {
  background-color: #4CAF50;
}

@media screen and (max-width: 500px) {
  .navbar a {
    float: none;
    display: block;
  }
}
</style>

</head>
<body>
	
			<div class="navbar">
  <a class="active" href="project.php"><i class="fa fa-fw fa-home"></i> Home</a> 
</div>
	<center>
		<br><br><br><br><br><br><br>
	<body background="4.jpg">

	<table>
		<tr>
			<td><button onclick="openpage()">Open Agents Database</button></td>
			
		</tr>
		
	</table>
	<br>
	<table>
		<tr>
			<td><button onclick="openUsers()">Open Users Database</button></td>
		</tr>
	</table>
	<br>
	<table>
		<tr>
			<td><button onclick="openSer()">Show User Service Request</button></td>
		</tr>
	</table>
</center>

</body>
</html>
  