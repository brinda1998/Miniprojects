<!DOCTYPE html>
<html>
<head>
	<title>Packers and Movers</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
body {font-family: Arial, Helvetica, sans-serif;}

.container {
    padding: 10px;
}

/* The Modal (background) */
.modal {
    display: none; /* Hidden by default */
    position: fixed; /* Stay in place */
    z-index: 1; /* Sit on top */
    left: 0;
    top: 0;
    width: 100%; /* Full width */
    height: 100%; /* Full height */
    overflow: auto; /* Enable scroll if needed */
    background-color: rgb(0,0,0); /* Fallback color */
    background-color: rgba(0,0,0,0.4); /* Black w/ opacity */
    padding-top: 60px;
}

/* Modal Content/Box */
.modal-content {
    background-color: #fefefe;
    margin: 5% auto 15% auto; /* 5% from the top, 15% from the bottom and centered */
    border: 1px solid #666;
    width: 70%; /* Could be more or less, depending on screen size */
}

/* The Close Button (x) */
.close {
    position: absolute;
    right: 25px;
    top: 0;
    color: #000;
    font-size: 35px;
    font-weight: bold;
}

.close:hover,
.close:focus {
    color: red;
    cursor: pointer;
}

/* Add Zoom Animation */
.animate {
    -webkit-animation: animatezoom 0.6s;
    animation: animatezoom 0.6s
}

@-webkit-keyframes animatezoom {
    from {-webkit-transform: scale(0)} 
    to {-webkit-transform: scale(1)}
}
    
@keyframes animatezoom {
    from {transform: scale(0)} 
    to {transform: scale(1)}
}
 
}
</style>


	<style>
table {
    font-family: arial, sans-serif;
    border-collapse: collapse;
    width: 10%;
}

td, th {
    border: 1px solid #dddddd;
    text-align: right;
    padding: 8px;
}

tr:nth-child(even) {
    background-color: #dddddd;
}
</style>
<style>
.button {
    background-color: #FF91AF;
    border: none;
    color: black;
    padding: 10px 20px;
    text-align: center;
    text-decoration: none;
    display: inline-block;
    margin: 4px 2px;
    cursor: pointer;
    border-radius: 16px;
}

.button:hover {
    background-color: #f1f1f1;
}
</style>

<script>
/*calling agents registration page*/
function openWin() {
    location.replace("agents.php");
}
</script>

<script>
    /*calling about US page*/
function openAbt() {
    location.replace("aboutus.php");
}
</script>

<script>
/*calling User Sign IN page*/
function openSignin() {
    location.replace("signin.php");
}
</script>

<script>
/*calling admin Sign IN page*/
function openAdmin() {
    location.replace("adminSignIN.php");
}
</script>
</head>
<body>
	<body background="banner_bg.jpg">
	<table>
		<tr>
	<td><button onclick="openAbt()">AboutUS</button></td>
	<td><button onclick="document.getElementById('id02').style.display='block'" style="width:auto;">Contact</button></td>
    <td><button onclick="openSignin()">SignIN</button></td>
	<td><button onclick="openWin()">Agents</button></td>
    <td><button onclick="openAdmin()">Admin</button></td>
</tr>
<h2><left><B><img src="logo1.jpg" alt="Logo Icon" style="width:50px;height:50px;">packers and movers</B></left></left></h2>

</table>
	<br><br><br><br><br><br><br><br>
	<font size="46" style="transform: jester"><center><caption>Where are you shifting?</caption>
        <br><br><br>
        <h6><center><a href="crac.php">Create new account</a></centre></h6>
        <div id="id02" class="modal">
  
  <form class="modal-content animate">
    <div class="imgcontainer">
      <span onclick="document.getElementById('id02').style.display='none'" class="close" title="Close Modal">&times;</span>
    </div>

    <div class="container">
      <p>Contact number:- 
        <table>
            <tr>
                <td>Aruna 7899454507</td>
                <td>Brindashree 8971330062</td>
            </tr></table>
        </p>
      <p>Email_ID:-
        <table>
            <tr>
                <td>arukushi06@gmail.com</td>
            </tr>
            <tr>
                <td>brindashreebv@gmail.com</td>
            </tr>
        </table></p>
  </div>
    <div class="container" style="background-color:#f1f1f1">

    </div>
  </form>
</div>
 



<script>
// Get the modal
var modal = document.getElementById('id01');

// When the user clicks anywhere outside of the modal, close it
window.onclick = function(event) {
    if (event.target == modal) {
        modal.style.display = "none";
    }
}
</script>


</body>
</html>

