<!DOCTYPE html>
<html>
<head>
	<title>Customer Details</title>
<style>
.button {
  display: inline-block;
  padding: 10px 15px;
  font-size: 15px;
  cursor: pointer;
  text-align: center;
  text-decoration: none;
  outline: none;
  color: #fff;
  background-color: #4CAF50;
  border: none;
  border-radius: 15px;
  box-shadow: 0 9px #999;
}

.button:hover {background-color: #3e8e41}

.button:active {
  background-color: #3e8e41;
  box-shadow: 0 5px #666;
  transform: translateY(4px);
}
</style>

<script>
function openSignOut() {
    location.replace("project.php");
}
</script>
<style>
.right {
    position: absolute;
    right: 0px;
    width: 300px;
    border: 3px solid #73AD21;
    padding: 20px;
}
</style>
</head>
<body>
	<body background="register.jpg">
	<button class="button" onclick="openSignOut()">SignOut</button>
	
<div class="right">
	<p><h3><b>your request has been registered!</b></h3></p>
		<?php
  	$a=$_POST['Agents_name'];
		echo "Agent Name:$a";
		?>
		<br><br>
		<?php
		$b=$_POST['Req_date'];
		echo "Req_date:$b";
		?>
		<br><br>
		Up_date:
		<?php
		$c=$_POST['Up_date'];
		echo $c;
		?>
		<br><br>
		From:
		<?php
			$d=$_POST['From_Place'];
		echo $d;
		?>
		<br><br>
		To:
		<?php
		$e=$_POST['To_Place'];
		echo $e;
		?>
	</div>
	<br><br><br><br><br><br>

</body>
</html>


<?php
	$Agent_name=$_POST['Agents_name'];
	$Req_date=$_POST['Req_date'];
	$Up_date=$_POST['Up_date'];
	$From=$_POST['From_Place'];
	$To=$_POST['To_Place'];
	
$servername = "localhost";
$username = "AB";
$password = "kushi06";
$db="packers and movers";
// Create connection
$conn = new mysqli($servername, $username, $password, $db);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 


$query="insert into service_req(Agent_name,Req_date,Up_date,From_Place,To_Place) values('$Agent_name','$Req_date','$Up_date','$From','$To')";
if ($conn->query($query) === TRUE) {
    echo "Your record created successfully";
} else {
    echo "Error: " . $query . "<br>" . $conn->error;
}
$conn->close();

?>