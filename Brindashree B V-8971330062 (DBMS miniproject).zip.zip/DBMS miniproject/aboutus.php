<!DOCTYPE html>
<html>
<head>
	<title>AboutUS</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
* {
    box-sizing: border-box;
}

body {
    font-family: Arial, Helvetica, sans-serif;
}

/* Style the header */
header {
    background-color: #666;
    padding: 0.1px;
    text-align: center;
    font-size: 25px;
    color: white;
}

/* Create two columns/boxes that floats next to each other */

article {
    float: left;
    padding: 20px;
    width: 100%;
    background-color: #f1f1f1;
    height: 300px; /* only for demonstration, should be removed */
}

/* Clear floats after the columns */
section:after {
    content: "";
    display: table;
    clear: both;
}

/* Style the footer */
footer {
    background-color: #777;
    padding: 1px;
    text-align: center;
    color: white;
}

/* Responsive layout - makes the two columns/boxes stack on top of each other instead of next to each other, on small screens */
@media (max-width: 600px) {
    nav, article {
        width: 100%;
        height: auto;
    }
}
</style>
 <style>
.centeralign {
  text-align: center;
}
</style>
<style> .indented { padding-left: 50pt; padding-right: 50pt; } </style>
</head>
<body>
    
<header>
  <h2><u>About US</u></h2>
</header>

<section>
  <p class="indented">
          We, packers and movers, have a customer oriented approach towards the varied needs of our clients. Our company situated in Bangalore, is built on the strong principles of safety, integrity and reliability. We offer to our clients cost effective and prompt moving & packaging services and goods transportation services, addressing the varied needs of customers throughout India.
          <br><br>
       Our company strictly adheres to set international standards and is known in the market for giving outstanding and hassle-free premium quality services like household goods packing services, household goods relocation services, Industries & office relocations, cargo transportation services, household goods transportation services, commercial goods transportation services, cargo moving services, domestic cargo services, Industrial transportation and packing services, heavy machinery transportation services, O.D.C transportation services etc. Team of talented and expert professionals and cargo services backs our company, ensuring on time and safe delivery of goods anywhere in India.
        </p>
  <article>
    <h1>Services</h1>
   <ol>
                <li>Packaging the goods.</li>
                <li>Proper warehousing facilities for its storage.</li>
                <li>Unloading and un-packaging of goods.</li>
                <li>Adequate transit insurance for the goods.</li>
                <li>Handling of goods by our experienced and trained staff, during all shifting processes.</li>
                <li>Household goods packing services.</li>
                <li>Transportation all over in India.</li>
                <li>Industrial packaging services.</li>
                <li>Heavy machinery shifting.</li>
                <li>O.D.C (Over dimension cargo) shifting and transportation.</li>
            </ol>
  </article>
  <footer>
      <h3><a href="project.php"><div class="w3-display-bottommiddle w3-hide-small">Back to Home</div></a></h3>
  </footer>
</section>
</body>
</html>