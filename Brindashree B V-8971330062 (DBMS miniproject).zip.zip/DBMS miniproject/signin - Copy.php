<!DOCTYPE html>
<html>
<head>
  <title>User SignIN</title>
  <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
  <link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>

<div class="login">

  <body background="reg.jpg">
<center>
  <br><br><br><br><br>
  <h3><div class="w3-display-middle w3-hide-small">User SignIN here!</h3>
    <table width="100%" border="0">
  
  <tr>
  
    <td valign="top"><div align="center">
      <form name="form1" method="post" action="signin.php">
      <table width="200" border="0">
        <tr>
           <div class="input1">
                <label for="name">Username</label>
                <input type="text"  name="name" id="name" required="" placeholder="Username"><br/>
                </div>
                </tr>
                <br>
        <tr>
           <div class="input1">
                <label for="pass" >Password</label>
                <input type="password" name="pass" id="pass" required="" placeholder="Password"><br/></div>
        </tr>
        
        <tr>
          <td colspan=2 align=center class="errors">
      <input name="submit" type="submit" id="submit" value="Login"></td>
        </tr>
        
      </table>
      
    </form></td>
  </tr>
</table>

<?php

$servername = "localhost";
$username = "AB";
$password = "kushi06";
$db="packers and movers";

//Create connection
$conn = new mysqli($servername, $username, $password, $db);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 
 
if(isset($_POST['name']))
{
    $uname=$_POST['name'];
    $pass=$_POST['pass'];

  
    $sql="SELECT * FROM `password` WHERE Username='".$uname."' AND Password='".$pass."' limit 1 ";
    
    $result=mysqli_query($conn,$sql);
   
    if(mysqli_num_rows($result)==1)
    {
       $_SESSION['success']="you are now logged in";
       header('Location:opt.php');
    }
  
    else
    {
        echo '<script type="text/javascript">alert("invalid username/password")</script>';
        /*include 'adminSignIN.php'; */  

         }
}

?>


</body>
</html>